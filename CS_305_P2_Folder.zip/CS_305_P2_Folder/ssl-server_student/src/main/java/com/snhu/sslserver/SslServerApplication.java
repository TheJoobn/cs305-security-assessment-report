package com.snhu.sslserver;
//=====================================================================================================   
//=====================================================================================================   
//Spring Boot imports
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//Security/encoding imports
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;

//=====================================================================================================
@SpringBootApplication
@RestController
public class SslServerApplication {

	// Entry point of the Spring Boot application
    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

//=====================================================================================================
    // Endpoint for checksum of hardcoded string 
    @GetMapping("/checksum")
    public String getChecksum() {
        String data = "Hello World Check Sum - By Jaden B. Knutson";
        return formatResponse(data, checksum(data));
    }

//=====================================================================================================   
    // Endpoint to get checksum of provided data 
    @GetMapping("/hash")
    public String getHash(@RequestParam String data) {
        return formatResponse(data, checksum(data));
    }

//=====================================================================================================      
    // Calculate SHA-256 checksum
    private String checksum(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(data.getBytes(StandardCharsets.UTF_8));
            BigInteger number = new BigInteger(1, hash);
            StringBuilder hexString = new StringBuilder(number.toString(16));
            while (hexString.length() < 32) {
                hexString.insert(0, '0');
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return "Checksum algorithm error";
        }
    }
//=====================================================================================================       
    // Formats response with HTML tags
    private String formatResponse(String data, String checksum) {
        return String.format("<p>Data: %s</p><p>Checksum (SHA-256): %s</p>", data, checksum);
    }
}
//=====================================================================================================   
//=====================================================================================================   